import React, { useEffect } from "react";
import { useSelector, useDispatch } from 'react-redux';
import { TouchableOpacity, View, Text } from 'react-native';
import { increase, decrease, refresh } from './Slice'; // Slice dosyanızın gerçek yolunu ekleyin

export const Counter = () => {
  const counter = useSelector((state) => state.counter);
  const dispatch = useDispatch();

  useEffect(() => {
    console.log(counter);
  }, [counter]);

  return (
    <View
      style={{
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "#AAAAAA",
        borderRadius: 10,
        width: 200,
        height: 200,
      }}
    >
      <Text style={{ color: "red", fontWeight: "bold", fontSize: 45 }}>
        {counter.count}
      </Text>
      <Presser text={"Increase"} onPress={() => dispatch(increase())} />
      <Presser text={"Decrease"} onPress={() => dispatch(decrease())} />
      <Presser text={"Refresh"} onPress={() => dispatch(refresh())} />
    </View>
  );
};

const Presser = ({ text, onPress }) => {
  return (
    <TouchableOpacity onPress={() => onPress()}>
      <View
        style={{
          justifyContent: "center",
          alignItems: "center",
          backgroundColor: "blue",
          borderRadius: 10,
          width: 100,
          height: 30,
          margin: 3,
        }}
      >
        <Text style={{ 
          color: "red", 
          fontWeight: "bold", 
          fontSize: 10 }}>
          {text}
        </Text>
      </View>
    </TouchableOpacity>
  );
};
