import { Text, SafeAreaView, StyleSheet } from 'react-native';
import { Card } from 'react-native-paper';
import { Store } from './Store';
import { Counter } from './Counter'; 
import { Provider } from 'react-redux';

//createSlice
//createStore
//useSelector 
//useDispatch


export default function App() {
  return (
    <Provider store={Store}>
    <SafeAreaView style={styles.container}>
    <Text></Text>
      <Card style={{justifyContent:"center", alignItems:"center"}}>
        <Text style={styles.paragraph}>
        </Text>
          <Counter/>
      </Card>
    </SafeAreaView>
    </Provider>
    
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
